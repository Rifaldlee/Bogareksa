package com.bogareksa.ui.pembeli.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.bogareksa.ui.pembeli.data.Product

@Entity(tableName = "cart_table")
data class CartEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val product: Product,
    val amount: Int
)
