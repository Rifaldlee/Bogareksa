package com.bogareksa.ui.penjual.mainSellerComponent

import androidx.compose.runtime.Composable

@Composable
fun HorizontalSpace(){

}