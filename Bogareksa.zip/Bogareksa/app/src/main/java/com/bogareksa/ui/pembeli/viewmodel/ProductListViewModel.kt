package com.bogareksa.ui.pembeli.viewmodel

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bogareksa.ui.pembeli.CustomerRepository
import com.bogareksa.ui.pembeli.data.OrderProduct
import com.bogareksa.ui.pembeli.data.remote.ProductResponse
import com.bogareksa.ui.pembeli.state.UiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

class ProductListViewModel (private val repository: CustomerRepository): ViewModel() {

    private val _product: MutableLiveData<List<ProductResponse>> = MutableLiveData()
    var product: LiveData<List<ProductResponse>> = _product

    fun getProducts(){
        viewModelScope.launch {
            _product.postValue(repository.getAllProduct())
        }
    }

    private val _query = mutableStateOf("")
    val query: State<String> get() = _query

    fun search(newQuery: String) {
        _query.value = newQuery
        val searchResult = repository.searchProduct(_query.value)
            .sortedBy { it.product.name }
    }
}