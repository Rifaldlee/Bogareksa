package com.bogareksa.ui.pembeli.data.remote

import retrofit2.http.GET

interface ApiService {
    @GET("products")
    fun getProducts(): List<ProductResponse>
}