package com.bogareksa.ui.pembeli

import android.app.Application
import com.bogareksa.ui.pembeli.data.FakeDataSource
import com.bogareksa.ui.pembeli.data.OrderProduct
import com.bogareksa.ui.pembeli.data.local.CartDao
import com.bogareksa.ui.pembeli.data.local.CartDatabase
import com.bogareksa.ui.pembeli.data.local.CartEntity
import com.bogareksa.ui.pembeli.data.remote.ApiConfig
import com.bogareksa.ui.pembeli.data.remote.ApiService
import com.bogareksa.ui.pembeli.data.remote.ProductResponse
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import retrofit2.Call

class CustomerRepository(application: Application) {
    private val apiService: ApiService
    private val cartDao: CartDao
    private val orderProduct = mutableListOf<OrderProduct>()

    init{
        if (orderProduct.isEmpty()){
            FakeDataSource.productData.forEach{
                orderProduct.add(OrderProduct(it, 0))
            }
        }
        val db = CartDatabase.getInstance(application)
        cartDao = db.cartDAO()
        apiService = ApiConfig.getApiService()
    }

    fun getAllProduct(): List<ProductResponse> {
        return apiService.getProducts()
    }

    fun getOrderProductById(productId: Long): OrderProduct {
        return orderProduct.first {
            it.product.id == productId
        }
    }

    fun getAddedOrderProduct(): Flow<List<CartEntity>> {
        return cartDao.getAllCartItems()
    }

    fun searchProduct(query: String): List<OrderProduct> {
        return FakeDataSource.productData.filter {
            it.name.contains(query, ignoreCase = true)
        }.map { OrderProduct(it, 0) }
    }

    suspend fun addToCart(productId: Long) {
        val existingOrderProduct = cartDao.getOrderProductById(productId)

        if (existingOrderProduct != null) {
            val updatedProduct = existingOrderProduct.copy(amount = existingOrderProduct.amount + 1)
            cartDao.addToCart(updatedProduct)
        } else {
            val productToAdd = FakeDataSource.productData.firstOrNull { it.id == productId }
            if (productToAdd != null) {
                val orderProductEntity = CartEntity(0, productToAdd, 1)
                cartDao.addToCart(orderProductEntity)
            }
        }
    }

    fun updateOrderProduct(productId: Long, newAmountValue: Int): Flow<Boolean> {
        val index = orderProduct.indexOfFirst { it.product.id == productId }
        val result = if (index >= 0) {
            val updatedOrderProduct = orderProduct[index].copy(amount = newAmountValue)
            orderProduct[index] = updatedOrderProduct
            true
        } else {
            false
        }
        return flowOf(result)
    }

    companion object {
        @Volatile
        private var instance: CustomerRepository? = null

        fun getInstance(application: Application): CustomerRepository =
            instance ?: synchronized(this) {
                CustomerRepository(application).apply {
                    instance = this
                }
            }
    }
}