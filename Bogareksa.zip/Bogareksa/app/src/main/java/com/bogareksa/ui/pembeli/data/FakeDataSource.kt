package com.bogareksa.ui.pembeli.data

import com.bogareksa.R

object FakeDataSource {
    val productData = listOf(
        Product(1, R.drawable.food, "Fast Food1", "Description", 90000, "12-31-2023"),
        Product(2, R.drawable.food, "Fast Food2", "Description", 90000, "12-31-2023"),
        Product(3, R.drawable.food, "Fast Food3", "Description", 90000, "12-31-2023"),
        Product(4, R.drawable.food, "Fast Food4", "Description", 90000, "12-31-2023"),
        Product(5, R.drawable.food, "Fast Food5", "Description", 90000, "12-31-2023"),
        Product(6, R.drawable.food, "Fast Food6", "Description", 90000, "12-31-2023"),
        Product(7, R.drawable.food, "Fast Food7", "Description", 90000, "12-31-2023"),
        Product(8, R.drawable.food, "Fast Food8", "Description", 90000, "12-31-2023"),
        Product(9, R.drawable.food, "Fast Food9", "Description", 90000, "12-31-2023"),
    )
}