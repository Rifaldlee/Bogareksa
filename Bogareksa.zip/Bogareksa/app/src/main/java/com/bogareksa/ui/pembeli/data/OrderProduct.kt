package com.bogareksa.ui.pembeli.data

data class OrderProduct(
    val product: Product,
    val amount: Int
)